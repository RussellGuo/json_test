﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Linq;

namespace MHTool.Setting
{
    public class ConfigOption
    {
        public string Value;
        public bool IsConfigured = false;
    }
}
